$(document).ready(function() {
	$('#userForm').bootstrapValidator({
		feedbackIcons: {
			valid: 'glyphicon glyphicon-ok',
			invalid: 'glyphicon glyphicon-remove',
			validating: 'glyphicon glyphicon-refresh'
		},
		fields: {
			nome: {
				container: '#infoNome',
				validators: {
					notEmpty: {
						message: 'Il campo nome non pu&ograve; essere vuoto'
					},
					regexp: {
						regexp: /^[a-zA-Z .'-]{2,30}$/,
						message: 'Da 2 a 30 catatteri (Solo lettere accettate)'
					}
				}
			},
			cognome: {
				container: '#infoCognome',
				validators: {
					notEmpty: {
						message: 'Il campo cognome non pu&ograve; essere vuoto'
					},
					regexp: {
						regexp: /^[a-zA-Z .'-]{2,30}$/,
						message: 'Da 2 a 30 caratteri (Solo lettere accettare)'
					}
				}
			},
			indirizzo: {
				container: '#infoIndirizzo',
				validators: {
					notEmpty: {
						message: 'Il campo indirizzo non pu&ograve; essere vuoto'
					},
					regexp: {
						regexp: /^[a-zA-Z ,.'-]+[0-9]{1,4}$/,
						message: 'Inserire indirizzo con numero civico'
					}
				}
			},
			cap: {
				container: '#infoCap',
				validators: {
					notEmpty: {
						message: 'Il campo cap non pu&ograve; essere vuoto'
					},
					regexp: {
						regexp: /^[0-9]{5}$/,
						message: 'Inserire 5 cifre per il cap'
					}
				}
			},
			nascita: {
				container: '#infoNascita',
				validators: {
					notEmpty: {
						message: 'Il campo nascita non pu&ograve; essere vuoto'
					},
					date: {
						format: 'DD/MM/YYYY',
						message: 'Data non valida. Formato: dd/mm/yyyy'
					}
				}
			},
			username: {
				container: '#infoUsername',
				validators: {
					notEmpty: {
						message: 'Il campo username non pu&ograve; essere vuoto'
					},
					regexp: {
						regexp: /^[a-zA-Z0-9]{3,10}$/,
						message: 'Da 3 a 30 catatteri (Solo lettere accettate)'
					}
				}
			},
			password: {
				container: '#infoPassword',
				validators: {
					notEmpty: {
						message: 'Il campo password non pu&ograve; essere vuoto'
					},
					regexp: {
						regexp: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{5,20}$/,
						message: 'Da 5 a 20 catatteri (Almeno una lettera minuscola, MAIUSCOLA, carattere speciale(#@%!?-) e un numer0)'
					}
				}
			},
			email: {
				container: '#infoEmail',
				validators: {
					notEmpty: {
						message: 'Il campo email non pu&ograve; essere vuoto'
					},
					regexp: {
						regexp: /^[\w\-\.\+]+\@[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,5}$/,
						message: 'Inserisci un e-mail valida'
					}
				}
			}
		}
	});
});