package test.com.fil.businesscomponent.security;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.fil.businesscomponent.security.Algoritmo;

class AlgoritmiTest {

	@Test
	void testAlgoritmo() {
		String password = Algoritmo.converti("Pass01$");
		assertNotNull(password);
		System.out.println(password);
	}

}
