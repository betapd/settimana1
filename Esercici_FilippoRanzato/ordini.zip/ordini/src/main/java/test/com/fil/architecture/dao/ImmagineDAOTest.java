package test.com.fil.architecture.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;

import java.sql.Connection;

import org.junit.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;

import com.fil.architecture.dao.DAOException;
import com.fil.architecture.dao.ImmagineDAO;
import com.fil.businesscomponent.model.Immagine;
import com.fil.architecture.dbaccess.DBAccess;

@TestMethodOrder(OrderAnnotation.class)
class ImmagineDAOTest {
	private static Immagine immagine;
	private static Connection conn;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		conn = DBAccess.getConnection();
		immagine = new Immagine();
		immagine.setIdImg(1);
		immagine.setUrl("PROVA URL1");
		immagine.setDescrizione("PROVA DESCRIZIONE1");
	}

	@Test
	@Order(1)
	void testCreate() {
		try {
			ImmagineDAO.getFactory().create(conn, immagine);
			System.out.println("Creata immagine");
		} catch (DAOException exc) {
			exc.printStackTrace();
			fail(exc.getMessage());
		}
	}

	@Test
	@Order(2)
	void testUpdateGetByID() {
		try {
			immagine = new Immagine();
			immagine.setIdImg(1);
			immagine.setUrl("UPDATE URL1");
			immagine.setDescrizione("UPDATE DESCRIZIONE1");
			ImmagineDAO.getFactory().update(conn, immagine);
			System.out.println("Modificato immagine");
			Immagine img = ImmagineDAO.getFactory().getById(conn, immagine);
			System.out.println(img.getUrl());
			System.out.println(img.getDescrizione());
		} catch (DAOException exc) {
			exc.printStackTrace();
			fail(exc.getMessage());
		}
	}

	@Test
	@Order(3)
	void testGetAll() {
		try {
			Immagine[] immagini = ImmagineDAO.getFactory().getAll(conn);
			assertNotNull(immagini);
		} catch (DAOException exc) {
			exc.printStackTrace();
			fail(exc.getMessage());
		}
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		try {
			ImmagineDAO.getFactory().delete(conn, immagine);
			immagine = null;
			System.out.println("Eliminato immagine");
		} catch (DAOException exc) {
			exc.printStackTrace();
			fail(exc.getMessage());
		}
	}

}
