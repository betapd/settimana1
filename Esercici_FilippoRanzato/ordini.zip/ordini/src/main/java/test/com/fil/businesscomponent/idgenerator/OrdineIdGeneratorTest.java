package test.com.fil.businesscomponent.idgenerator;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.Test;

import com.fil.architecture.dao.DAOException;
import com.fil.businesscomponent.idgenerator.OrdineIdGenerator;

class OrdineIdGeneratorTest {

	@Test
	void testGenerator() {
		try {
			OrdineIdGenerator idGen = OrdineIdGenerator.getInstance();
			assertNotNull(idGen, "1.01: Istanza generata correttamente");
			long valore = idGen.getNextId();
			assertEquals(valore, idGen.getNextId() - 1);
		} catch (ClassNotFoundException | DAOException | IOException exc) {
			fail(exc.getMessage());
		}
	}

}
