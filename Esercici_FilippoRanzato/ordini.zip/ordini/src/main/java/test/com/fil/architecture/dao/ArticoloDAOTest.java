package test.com.fil.architecture.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import static org.junit.jupiter.api.Assertions.fail;

import java.sql.Connection;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import com.fil.architecture.dao.ArticoloDAO;
import com.fil.architecture.dao.DAOException;
import com.fil.architecture.dbaccess.DBAccess;
import com.fil.businesscomponent.model.Articolo;

@TestMethodOrder(OrderAnnotation.class)
class ArticoloDAOTest {
	private static Articolo articolo;
	private static Connection conn;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		conn = DBAccess.getConnection();
		articolo = new Articolo();
		articolo.setIdArticolo(6);
		articolo.setMarca("Apple");
		articolo.setModello("Air");
		articolo.setPrezzo(1200.00);
	}

	@Test
	@Order(1)
	void testCreate() {
		try {
			ArticoloDAO.getFactory().create(conn, articolo);
			System.out.println("Creato articolo");
		} catch (DAOException exc) {
			exc.printStackTrace();
			fail(exc.getMessage());
		}
	}
	
	@Test
	@Order(2)
	void testUpdateGetByID() {
		try {
			articolo = new Articolo();
			articolo.setIdArticolo(6);
			articolo.setMarca("Apple");
			articolo.setModello("Macbook Pro");
			articolo.setPrezzo(1400.00);
			ArticoloDAO.getFactory().update(conn, articolo);
			System.out.println("Modificato articolo");
			Articolo art = ArticoloDAO.getFactory().getById(conn, articolo);
			System.out.println(art.getModello());
			System.out.println(art.getPrezzo());
		} catch (DAOException exc) {
			exc.printStackTrace();
			fail(exc.getMessage());
		}
	}
	
	@Test
	@Order(3)
	void testGetAll() {
		try {
			Articolo[] articoli = ArticoloDAO.getFactory().getAll(conn);
			assertNotNull(articoli);
		} catch (DAOException exc) {
			exc.printStackTrace();
			fail(exc.getMessage());
		}
	}
	
	@AfterAll
	static void tearDownAfterClass() throws Exception {
		try {
			ArticoloDAO.getFactory().delete(conn, articolo);
			articolo = null;
			System.out.println("Eliminato articolo");
		} catch (DAOException exc) {
			exc.printStackTrace();
			fail(exc.getMessage());
		}
	}
}
