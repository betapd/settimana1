package test.com.fil.businesscomponent.idgenerator;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.Test;

import com.fil.architecture.dao.DAOException;
import com.fil.businesscomponent.idgenerator.ArticoloIdGenerator;

class ArticoloIdGeneratorTest {

	@Test
	void testGenerator() {
		try {
			ArticoloIdGenerator idGen = ArticoloIdGenerator.getInstance();
			assertNotNull(idGen, "1.01: Istanza generata correttamente");
			long valore = idGen.getNextId();
			assertEquals(valore, idGen.getNextId() - 1);
		} catch (ClassNotFoundException | DAOException | IOException exc) {
			fail(exc.getMessage());
		}
	}

}
