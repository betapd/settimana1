package test.com.fil.architecture.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;

import java.sql.Connection;
import java.util.Date;
import java.util.GregorianCalendar;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.fil.architecture.dao.DAOException;
import com.fil.architecture.dao.OrdineDAO;
import com.fil.architecture.dao.UtenteDAO;
import com.fil.architecture.dbaccess.DBAccess;
import com.fil.businesscomponent.model.Ordine;
import com.fil.businesscomponent.model.Utente;

class OrdineDAOTest {
	private static Ordine ordine;
	private static Utente utente;
	private static Connection conn;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		conn = DBAccess.getConnection();
		utente = new Utente();
		utente.setNome("Max");
		utente.setCognome("Rossi");
		utente.setIndirizzo("Via Milano, 10");
		utente.setCap("20100");
		utente.setNascita(new GregorianCalendar(1979, 10, 10).getTime());
		utente.setUsername("max01");
		utente.setPassword("Pass01");
		utente.setEmail("max@hotmail.com");

		ordine = new Ordine();
		ordine.setIdOrdine(1);
		ordine.setTotale(2000);
		ordine.setData(new Date());
		ordine.setUsername("max01");
	}

	@Test
	void testCreate() {
		try {
			UtenteDAO.getFactory().create(conn, utente);
			OrdineDAO.getFactory().create(conn, ordine);
			System.out.println("Creato utente e ordine");
		} catch (DAOException exc) {
			exc.printStackTrace();
			fail(exc.getMessage());
		}
	}

	@Test
	void testGetAll() {
		try {
			Ordine[] ordini = OrdineDAO.getFactory().getAll(conn);
			assertNotNull(ordini);
		} catch (DAOException exc) {
			exc.printStackTrace();
			fail(exc.getMessage());
		}
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		try {
			OrdineDAO.getFactory().delete(conn, ordine);
			UtenteDAO.getFactory().delete(conn, utente);
			ordine = null;
			utente = null;
			System.out.println("Eliminato utente e ordine");
		} catch (DAOException exc) {
			exc.printStackTrace();
			fail(exc.getMessage());
		}
	}
}
