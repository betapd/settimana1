package test.com.fil.architecture.dao;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;
import java.util.GregorianCalendar;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fil.architecture.dao.DAOException;
import com.fil.architecture.dao.UtenteDAO;
import com.fil.architecture.dbaccess.DBAccess;
import com.fil.businesscomponent.model.Utente;

class UtenteDAOTest {
	private Utente utente;
	private Connection conn;
	
	@BeforeEach
	void setUp() throws Exception {
		utente = new Utente(); 
		utente.setNome("Max");
		utente.setCognome("Rossi");
		utente.setIndirizzo("Via Milano, 10");
		utente.setCap("20100");
		utente.setNascita(new GregorianCalendar(1979,10,10).getTime());
		utente.setUsername("max01");
		utente.setPassword("Pass01");
		utente.setEmail("max@hotmail.com");
	}
	
	@Test
	void testCreate() {
		try {
			UtenteDAO.getFactory().create(DBAccess.getConnection(), utente);
			System.out.println("Creato utente");	
		} catch(ClassNotFoundException | DAOException | IOException exc) {
			exc.printStackTrace();
			fail(exc.getMessage());
		}	
	}

	@AfterEach
	void tearDown() throws Exception {
		utente = null;
		conn = DBAccess.getConnection();
		Statement stmt = conn.createStatement();
		stmt.executeUpdate("Delete from utente where username = 'max01'");
		conn.commit();
		DBAccess.closeConnection();
	}
}
