package test.com.fil.architecture.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;

import java.sql.Connection;
import java.sql.Statement;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.fil.architecture.dao.AmministratoreDAO;
import com.fil.architecture.dao.DAOException;
import com.fil.businesscomponent.model.Amministratore;
import com.fil.architecture.dbaccess.DBAccess;

class AmministratoreDAOTest {
	private static Amministratore admin;
	private static Connection conn;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		conn = DBAccess.getConnection();
		admin = new Amministratore();
		admin.setUsername("nuovoAdmin");
		admin.setPassword("pswAdmin");
		admin.setEmail("admin@admin.com");
	}

	@Test
	void testCreate() {
		try {
			AmministratoreDAO.getFactory().create(conn, admin);
			System.out.println("Creato amministratore");
		} catch (DAOException exc) {
			exc.printStackTrace();
			fail(exc.getMessage());
		}
	}

	@Test
	void testUpdate() {
		try {
			admin = new Amministratore();
			admin.setUsername("nuovoAdmin");
			admin.setPassword("newPassword");
			admin.setEmail("adalpo@hotmail.com");
			AmministratoreDAO.getFactory().update(conn, admin);
			System.out.println("Modificato amministratore");
			Amministratore a = AmministratoreDAO.getFactory().getById(conn, admin);
			System.out.println(a.getUsername());
			System.out.println(a.getPassword());
			System.out.println(a.getEmail());
		} catch (DAOException exc) {
			exc.printStackTrace();
			fail(exc.getMessage());
		}
	}

	@Test
	void testGetAll() {
		try {
			Amministratore[] admins = AmministratoreDAO.getFactory().getAll(conn);
			assertNotNull(admins);
			System.out.println("test get all ok");
		} catch (DAOException exc) {
			exc.printStackTrace();
			fail(exc.getMessage());
		}
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		admin = null;
		conn = DBAccess.getConnection();
		Statement stmt = conn.createStatement();
		stmt.executeUpdate("Delete from amministratore where username = 'nuovoAdmin'");
		conn.commit();
		System.out.println("Admin cancellato");
		DBAccess.closeConnection();
	}
}
