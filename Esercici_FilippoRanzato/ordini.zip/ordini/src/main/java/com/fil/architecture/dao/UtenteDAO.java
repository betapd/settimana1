package com.fil.architecture.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.RowSetProvider;

import com.fil.businesscomponent.model.Utente;
import com.fil.businesscomponent.security.Algoritmo;

public class UtenteDAO implements GenericDAO<Utente>, DAOConstants {
	private CachedRowSet rowSet;

	private UtenteDAO() throws DAOException {
		try {
			rowSet = RowSetProvider.newFactory().createCachedRowSet();
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
	}
	
	public static UtenteDAO getFactory() throws DAOException {
		return new UtenteDAO();
	}
	
	@Override
	public void create(Connection conn, Utente model) throws DAOException {
		try {
			rowSet.setCommand(SELECT_UTENTE);
			rowSet.execute(conn);
			rowSet.moveToInsertRow();
			rowSet.updateString(1, model.getNome());
			rowSet.updateString(2, model.getCognome());
			rowSet.updateString(3, model.getIndirizzo());
			rowSet.updateString(4, model.getCap());
			rowSet.updateDate(5, new java.sql.Date(model.getNascita().getTime()));
			rowSet.updateString(6, model.getUsername());
			rowSet.updateString(7, Algoritmo.converti(model.getPassword()));
			rowSet.updateString(8, model.getEmail());
			rowSet.insertRow();
			rowSet.moveToCurrentRow();
			rowSet.acceptChanges();
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
	}

	@Override
	public void update(Connection conn, Utente model) throws DAOException {

	}

	@Override
	public void delete(Connection conn, Utente model) throws DAOException {
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(DELETE_UTENTE);
			ps.setString(1, model.getUsername());
			ps.execute();
			conn.commit();
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
	}

	@Override
	public Utente[] getAll(Connection conn) throws DAOException {
		return null;
	}

	@Override
	public Utente getById(Connection conn, Utente model) throws DAOException {
		return null;
	}

	@Override
	public Utente getById(Connection conn, long id) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}
}