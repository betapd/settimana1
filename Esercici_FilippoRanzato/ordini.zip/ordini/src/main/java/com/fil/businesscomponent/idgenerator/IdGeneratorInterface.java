package com.fil.businesscomponent.idgenerator;

import java.io.IOException;

import com.fil.architecture.dao.DAOException;

public interface IdGeneratorInterface {
	long getNextId() throws DAOException, ClassNotFoundException, IOException;
	
}
