package com.fil.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fil.architecture.dao.DAOException;
import com.fil.businesscomponent.AdminFacade;
import com.fil.businesscomponent.model.Articolo;
import com.fil.businesscomponent.model.Immagine;
import com.fil.businesscomponent.model.OrdineArticolo;

/**
 * Servlet implementation class DeleteArticolo
 */
@WebServlet("/rimuoviArticolo")
public class RimuoviArticolo extends HttpServlet {
  private static final long serialVersionUID = 1L;

  protected void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {

    HttpSession session = request.getSession();

    String id = request.getParameter("id");
    System.out.println(id);

    try {

      Articolo a = null;
      Immagine b = new Immagine();
      OrdineArticolo c = null;

      b = AdminFacade.getInstance().getImmagineById(Long.parseLong(id));
      if (b != null) {
        AdminFacade.getInstance().deleteImmagine(b);
      } else {

      }
      
      c = AdminFacade.getInstance().getOrdineArticoloById(Long.parseLong(id));
      if (c != null) {
        AdminFacade.getInstance().deleteOrdineArticolo(c);
      } else {
      }

      a = AdminFacade.getInstance().getArticoloById(Long.parseLong(id));
      AdminFacade.getInstance().deleteArticolo(a);
      
    } catch (DAOException | ClassNotFoundException exc) {
      exc.printStackTrace();
      throw new ServletException(exc.getMessage());
    }

    response.sendRedirect("admin/admin.jsp");
  }

}