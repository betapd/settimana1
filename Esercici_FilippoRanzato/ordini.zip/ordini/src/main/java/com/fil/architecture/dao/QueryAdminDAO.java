package com.fil.architecture.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.fil.businesscomponent.model.ProdottoVenduto;

public class QueryAdminDAO implements DAOConstants {

	private QueryAdminDAO() {
	}

	public static QueryAdminDAO createQueryAdminDAO() {
		return new QueryAdminDAO();
	}

	public String getArticoliNumero(Connection conn) throws DAOException {

		String totale = "";

		try {
			Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = stmt.executeQuery(TOT_ARTICOLI);

			if (rs.next()) {
				totale = rs.getString(1);
			}
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
		return totale;
	}

	public String getTotale(Connection conn) throws DAOException {

		String totale = "";

		try {
			Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = stmt.executeQuery(TOTALE);

			if (rs.next()) {
				totale = rs.getString(1);
			}
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
		return totale;
	}

	public String[] getMaxSpesa(Connection conn) throws DAOException {

		String s1 = "";
		String s2 = "";

		try {
			Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = stmt.executeQuery(UTENTE_MAX_SPESA);

			if (rs.next()) {
				s1 = rs.getString(1);
				s2 = rs.getString(2);
			}
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
		String[] dob = { s1, s2 };
		return dob;
	}

	public ProdottoVenduto[] getProdotto(Connection conn) throws DAOException {

		ProdottoVenduto[] pv = null;

		try {
			Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = stmt.executeQuery(PRODOTTO_PIU_VENDUTO);

			rs.last();
			pv = new ProdottoVenduto[rs.getRow()];
			rs.beforeFirst();

			for (int i = 0; rs.next(); i++) {
				ProdottoVenduto a = new ProdottoVenduto();

				a.setIdArticolo(rs.getLong(1));
				a.setMarca(rs.getString(2));
				a.setModello(rs.getString(3));
				a.setPrezzo(rs.getDouble(4));
				a.setCount(rs.getInt(5));
				pv[i] = a;
			}
			rs.close();
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
		return pv;
	}

}
