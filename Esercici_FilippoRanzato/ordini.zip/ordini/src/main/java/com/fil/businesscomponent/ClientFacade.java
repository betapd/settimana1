package com.fil.businesscomponent;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.fil.architecture.dao.DAOException;
import com.fil.businesscomponent.model.Articolo;
import com.fil.businesscomponent.model.Immagine;
//import com.fil.businesscomponent.model.Immagine;
import com.fil.businesscomponent.model.Ordine;
import com.fil.businesscomponent.model.OrdineArticolo;
import com.fil.businesscomponent.model.Utente;

public class ClientFacade {
	private static ClientFacade istanza;

	private ClientFacade() {

	}

	public static ClientFacade getInstance() {
		if (istanza == null)
			istanza = new ClientFacade();
		return istanza;
	}

	public void createUtente(Utente utente)
			throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		UtenteBC uBC = new UtenteBC();
		uBC.create(utente);
	}

	public void createOrdine(Ordine ordine)
			throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		OrdineBC oBC = new OrdineBC();
		oBC.create(ordine);
	}

	public void createOrdineArticolo(OrdineArticolo oa)
			throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		OrdineArticoloBC oBC = new OrdineArticoloBC();
		oBC.create(oa);
	}

	public Articolo[] getArticoli() throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		ArticoloBC aBC = new ArticoloBC();
		return aBC.getArticoli();
	}

	public Articolo[] searchArticolo(String query)
			throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		ArticoloBC aBC = new ArticoloBC();
		return aBC.searchArticolo(query);
	}

	public Articolo getArticoloById(Articolo articolo)
			throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		ArticoloBC aBC = new ArticoloBC();
		return aBC.getById(articolo);
	}

	public Immagine[] getImmagini() throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		ImmagineBC iBC = new ImmagineBC();
		return iBC.getImmagini();
	}
	
	

}
