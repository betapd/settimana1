package com.fil.businesscomponent;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import com.fil.architecture.dao.DAOException;
import com.fil.architecture.dao.OrdineArticoloDAO;
import com.fil.architecture.dbaccess.DBAccess;
import com.fil.businesscomponent.model.OrdineArticolo;

public class OrdineArticoloBC {
	private Connection conn;

	public OrdineArticoloBC() throws ClassNotFoundException, DAOException, FileNotFoundException, IOException {
		conn = DBAccess.getConnection();
	}

	public void create(OrdineArticolo oa) throws DAOException {
		try {
			OrdineArticoloDAO.getFactory().create(conn, oa);
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
	}

	public void delete(OrdineArticolo oa) throws DAOException {

		try {
			OrdineArticoloDAO.getFactory().delete(conn, oa);

		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
	}

	public OrdineArticolo getbyId(Long id) throws DAOException {
		try {
			return OrdineArticoloDAO.getFactory().getById(conn, id);

		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
	}

}