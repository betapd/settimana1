package com.fil.businesscomponent;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

import com.fil.architecture.dao.DAOException;
import com.fil.architecture.dao.OrdineDAO;
import com.fil.businesscomponent.idgenerator.OrdineIdGenerator;
import com.fil.businesscomponent.model.Ordine;
import com.fil.architecture.dbaccess.DBAccess;

public class OrdineBC {
	private Connection conn;
	private OrdineIdGenerator idGen;

	public OrdineBC() throws ClassNotFoundException, DAOException, FileNotFoundException, IOException {
		conn = DBAccess.getConnection();
		idGen = OrdineIdGenerator.getInstance();

	}

	public void create(Ordine ordine) throws DAOException, ClassNotFoundException, IOException {
		try {
			ordine.setIdOrdine(idGen.getNextId());
			ordine.setData(new Date());
			OrdineDAO.getFactory().create(conn, ordine);
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
	}

	public Ordine[] getOrdini() throws DAOException {
		Ordine[] ordini = null;
		try {
			ordini = OrdineDAO.getFactory().getAll(conn);
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
		return ordini;
	}

	public void delete(Ordine ordine) throws DAOException {
		try {
			OrdineDAO.getFactory().delete(conn, ordine);
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
	}

}
