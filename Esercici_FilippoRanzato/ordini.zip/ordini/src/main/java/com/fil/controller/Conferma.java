package com.fil.controller;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fil.architecture.dao.DAOException;
import com.fil.businesscomponent.Carrello;
import com.fil.businesscomponent.ClientFacade;
import com.fil.businesscomponent.model.Ordine;
import com.fil.businesscomponent.model.OrdineArticolo;


@WebServlet("/conferma")
public class Conferma extends HttpServlet {

	private static final long serialVersionUID = 789868400071059153L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		Carrello carrello = (Carrello)session.getAttribute("carrello");
		Ordine ordine = new Ordine();
		ordine.setTotale(carrello.totaleComplessivo());
		ordine.setUsername((String)session.getAttribute("username"));
		try {
			ClientFacade cF = ClientFacade.getInstance();
			cF.createOrdine(ordine);
			OrdineArticolo oa;
			Enumeration<String[]> prodotti = carrello.getElementi();
			while(prodotti.hasMoreElements()) {
				oa = new OrdineArticolo();
				String[] prodotto = prodotti.nextElement();
				oa.setIdOrdine(ordine.getIdOrdine());
				oa.setIdArticolo(Long.parseLong(prodotto[4]));
				oa.setQuantita(Integer.parseInt(prodotto[3]));
				cF.createOrdineArticolo(oa);
			}
			
			session.setAttribute("idOrdine", ordine.getIdOrdine());
			response.sendRedirect("ordina.jsp");
			
		} catch (DAOException | ClassNotFoundException exc) {
			exc.printStackTrace();
			throw new ServletException(exc.getMessage());
		}
	}
}
