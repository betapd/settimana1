package com.fil.businesscomponent;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import com.fil.architecture.dao.DAOException;
import com.fil.architecture.dao.QueryAdminDAO;
import com.fil.architecture.dbaccess.DBAccess;
import com.fil.businesscomponent.model.ProdottoVenduto;

public class QueryAdminBC {

	private Connection conn;

	public QueryAdminBC() throws ClassNotFoundException, DAOException, FileNotFoundException, IOException {

		conn = DBAccess.getConnection();

	}

	public String getTotale() throws ClassNotFoundException, DAOException, IOException {

		String tot = "";
		try {
			tot = QueryAdminDAO.createQueryAdminDAO().getTotale(conn);

		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
		return tot;
	}

	public String[] getSpesaMax() throws ClassNotFoundException, DAOException, IOException {

		String[] dob = null;
		try {
			dob = QueryAdminDAO.createQueryAdminDAO().getMaxSpesa(conn);

		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
		return dob;
	}

	public String getArticoliNumero() throws ClassNotFoundException, DAOException, IOException {

		String tot = "";
		try {
			tot = QueryAdminDAO.createQueryAdminDAO().getArticoliNumero(conn);

		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
		return tot;
	}

	public ProdottoVenduto[] getProdotto() throws DAOException {
		ProdottoVenduto[] pv = null;
		try {
			pv = QueryAdminDAO.createQueryAdminDAO().getProdotto(conn);
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
		return pv;
	}

}
