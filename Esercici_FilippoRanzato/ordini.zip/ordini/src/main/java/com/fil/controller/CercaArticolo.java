package com.fil.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fil.architecture.dao.DAOException;
import com.fil.businesscomponent.ClientFacade;
import com.fil.businesscomponent.model.Articolo;


@WebServlet("/cercaArticolo")
public class CercaArticolo extends HttpServlet {
  private static final long serialVersionUID = -8072133127085371558L;

  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    
    Articolo[] articolo = null;
    String parametro = request.getParameter("parametro");
    System.out.println(parametro);
    try {
      articolo = ClientFacade.getInstance().searchArticolo(parametro);
      request.setAttribute("articolo", articolo);
      
    } catch (DAOException | ClassNotFoundException | IOException exc) {
      exc.printStackTrace();
    }
    RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/acquisti.jsp");
    dispatcher.forward(request, response);
  }

}