package com.fil.businesscomponent;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.fil.architecture.dao.DAOException;
import com.fil.businesscomponent.model.Articolo;
import com.fil.businesscomponent.model.Immagine;
import com.fil.businesscomponent.model.Ordine;
import com.fil.businesscomponent.model.OrdineArticolo;
import com.fil.businesscomponent.model.ProdottoVenduto;


public class AdminFacade {
	private static AdminFacade istanza;

	private AdminFacade() {

	}

	public static AdminFacade getInstance() {
		if (istanza == null)
			istanza = new AdminFacade();
		return istanza;
	}

	public void deleteOrdine(Ordine ordine)
			throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		OrdineBC oBC = new OrdineBC();
		oBC.delete(ordine);
	}

	public Ordine[] getOrdini() throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		OrdineBC oBC = new OrdineBC();
		return oBC.getOrdini();
	}

	public void createOrUpdateArticolo(Articolo articolo)
			throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		ArticoloBC oBC = new ArticoloBC();
		oBC.createOrUpdate(articolo);
	}

	public void deleteArticolo(Articolo articolo)
			throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		ArticoloBC aBC = new ArticoloBC();
		aBC.delete(articolo);
	}

	public Articolo[] getArticoli() throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		ArticoloBC aBC = new ArticoloBC();
		return aBC.getArticoli();
	}

	public Articolo[] searchArticolo(String query)
			throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		ArticoloBC aBC = new ArticoloBC();
		return aBC.searchArticolo(query);
	}

	public Articolo getArticoloById(Articolo articolo)
			throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		ArticoloBC aBC = new ArticoloBC();
		return aBC.getById(articolo);
	}
	
	public Articolo getArticoloById(long id)
			throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		ArticoloBC aBC = new ArticoloBC();
		return aBC.getById(id);
	}
	
	public Immagine getImmagineById(long id)
		      throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		    ImmagineBC aBC = new ImmagineBC();
		    return aBC.getById(id);
	}
	
	public void deleteImmagine(Immagine immagine)
		      throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		    ImmagineBC aBC = new ImmagineBC();
		    aBC.delete(immagine);
	}
	
	public OrdineArticolo getOrdineArticoloById(Long id)
		      throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		    OrdineArticoloBC aBC = new OrdineArticoloBC();
		    return aBC.getbyId(id);
	}
	
	public void deleteOrdineArticolo(OrdineArticolo oa)
		      throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		    OrdineArticoloBC aBC = new OrdineArticoloBC();
		    aBC.delete(oa);
	}
	
	public String getArticoliNumero() throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		QueryAdminBC aBC = new QueryAdminBC();
		return aBC.getArticoliNumero();
	}
	
	public String getTotale() throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		QueryAdminBC aBC = new QueryAdminBC();
		return aBC.getTotale();
	}
	
	public ProdottoVenduto[] getProdotto()
			throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		QueryAdminBC aBC = new QueryAdminBC();
		return aBC.getProdotto();
	}

	public String[] getSpesaMax() throws DAOException, ClassNotFoundException, FileNotFoundException, IOException {
		QueryAdminBC aBC = new QueryAdminBC();
		return aBC.getSpesaMax();
	}
}
