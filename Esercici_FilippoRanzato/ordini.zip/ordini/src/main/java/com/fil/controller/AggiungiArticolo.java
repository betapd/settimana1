package com.fil.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fil.architecture.dao.DAOException;
import com.fil.businesscomponent.AdminFacade;
import com.fil.businesscomponent.model.Articolo;

@WebServlet("/inserisciArticolo")
public class AggiungiArticolo extends HttpServlet {
	private static final long serialVersionUID = -3961377836263286663L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Articolo articolo = getArticolo(request);
		
		if(articolo != null) {
		try {
			AdminFacade.getInstance().createOrUpdateArticolo(articolo);
			}catch (DAOException | ClassNotFoundException | IOException exc) {
				exc.printStackTrace();
				throw new ServletException(exc.getMessage());
			}
		}
		response.sendRedirect("/admin/gestisciArticoli.jsp");
	}
	
	public Articolo getArticolo(HttpServletRequest request) {
		Articolo art = null;
		try {
			art = new Articolo();
			art.setIdArticolo(Long.parseLong(request.getParameter("id")));
			art.setMarca(request.getParameter("marca"));
			art.setModello(request.getParameter("modello"));
			art.setPrezzo(Double.parseDouble(request.getParameter("prezzo")));
			
			
		} catch (Exception exc) {
			exc.printStackTrace();
		}
		return art;	
	}

}
