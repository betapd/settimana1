package com.fil.businesscomponent;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import com.fil.architecture.dao.DAOException;
import com.fil.architecture.dao.ImmagineDAO;
import com.fil.businesscomponent.idgenerator.ArticoloIdGenerator;
import com.fil.businesscomponent.model.Immagine;
import com.fil.architecture.dbaccess.DBAccess;

public class ImmagineBC {
	private Connection conn;
	private ArticoloIdGenerator idGen;

	public ImmagineBC() throws ClassNotFoundException, DAOException, FileNotFoundException, IOException {
		conn = DBAccess.getConnection();
		idGen = ArticoloIdGenerator.getInstance();
	}

	public void createOrUpdate(Immagine immagine) throws DAOException, ClassNotFoundException, IOException {
		try {
			if (immagine.getIdImg() > 0)
				ImmagineDAO.getFactory().update(conn, immagine);
			else {
				immagine.setIdImg(idGen.getNextId());
				ImmagineDAO.getFactory().create(conn, immagine);
			}
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
	}

	public Immagine[] getImmagini() throws DAOException {
		Immagine[] immagini = null;
		try {
			immagini = ImmagineDAO.getFactory().getAll(conn);
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
		return immagini;
	}

	public Immagine getById(Immagine immagine) throws DAOException {
		try {
			return ImmagineDAO.getFactory().getById(conn, immagine);
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
	}
	
	public Immagine getById(long id) throws DAOException {
		try {
			return ImmagineDAO.getFactory().getById(conn, id);
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
	}

	public void delete(Immagine immagine) throws DAOException {
		try {
			ImmagineDAO.getFactory().delete(conn, immagine);
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
	}

}