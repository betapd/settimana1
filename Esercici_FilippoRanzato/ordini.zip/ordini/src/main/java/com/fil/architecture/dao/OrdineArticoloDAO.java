package com.fil.architecture.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.RowSetProvider;

import com.fil.businesscomponent.model.OrdineArticolo;

public class OrdineArticoloDAO implements GenericDAO<OrdineArticolo>, DAOConstants {
  private CachedRowSet rowSet;

  private OrdineArticoloDAO() throws DAOException {
    try {
      rowSet = RowSetProvider.newFactory().createCachedRowSet();
    } catch (SQLException sql) {
      throw new DAOException(sql);
    }
  }

  public static OrdineArticoloDAO getFactory() throws DAOException {
    return new OrdineArticoloDAO();
  }

  @Override
  public void create(Connection conn, OrdineArticolo model) throws DAOException {
    try {
      rowSet.setCommand(SELECT_ORDINE_ARTICOLO);
      rowSet.execute(conn);
      rowSet.moveToInsertRow();
      rowSet.updateLong(1, model.getIdArticolo());
      rowSet.updateLong(2, model.getIdOrdine());
      rowSet.updateDouble(3, model.getQuantita());
      rowSet.insertRow();
      rowSet.moveToCurrentRow();
      rowSet.acceptChanges();
    } catch (SQLException sql) {
      throw new DAOException(sql);
    }

  }

  @Override
  public void update(Connection conn, OrdineArticolo ordArt) throws DAOException {
    try {
      rowSet.setCommand(SELECT_ORDINE_ARTICOLO);
      rowSet.execute(conn);
      rowSet.moveToInsertRow();
      rowSet.updateLong(1, ordArt.getIdOrdine());
      rowSet.updateLong(2, ordArt.getIdArticolo());
      rowSet.updateDouble(3, ordArt.getQuantita());
      rowSet.insertRow();
      rowSet.moveToCurrentRow();
      rowSet.acceptChanges();
    } catch (SQLException sql) {
      throw new DAOException(sql);
    }

  }

  @Override
  public void delete(Connection conn, OrdineArticolo model) throws DAOException {
    PreparedStatement ps;
    try {
      ps = conn.prepareStatement(DELETE_ORDINEARTICOLO);
      ps.setLong(1, model.getIdArticolo());
      ps.execute();
      conn.commit();
    } catch (SQLException sql) {
      throw new DAOException(sql);
    }

  }

  @Override
  public OrdineArticolo[] getAll(Connection conn) throws DAOException {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public OrdineArticolo getById(Connection conn, OrdineArticolo model) throws DAOException {
    // TODO Auto-generated method stub
    return null;
  }

  public OrdineArticolo getById(Connection conn, Long id) throws DAOException {
    OrdineArticolo oo = null;
    PreparedStatement ps;
    try {
      ps = conn.prepareStatement(SELECT_ORDINEARTICOLO_BY_ID);
      ps.setLong(1, id);
      ResultSet rs = ps.executeQuery();
      if (rs.next()) {
        oo = new OrdineArticolo();
        oo.setIdOrdine(rs.getLong(1));
        oo.setIdArticolo(rs.getLong(2));
        oo.setQuantita(rs.getInt(3));
      }
    } catch (SQLException sql) {
      throw new DAOException(sql);
    }
    return oo;
  }

@Override
public OrdineArticolo getById(Connection conn, long id) throws DAOException {
	// TODO Auto-generated method stub
	return null;
}

}