package com.fil.architecture.dao;

public interface DAOConstants {
	// -----------------------utente
	String SELECT_UTENTE = "select * from utente";
	String SELECT_ORDINE = "select * from ordine";
	String SELECT_ARTICOLO = "select * from articolo";
	String SELECT_ORDINE_ARTICOLO = "select * from ordine_articolo";
	String SELECT_IMMAGINE = "select * from immagine";

	
	String DELETE_UTENTE = "delete from ordine where username=?";
	String DELETE_IMMAGINE = "delete from immagine where id_img=?";
	String SELECT_USERPASS = "select password from utente where username=?";

	String SELECT_ORDINE_SEQ = "select ordine_seq.nextval from dual";

	String INSERT_ORDINE_ARTICOLO = "insert into ordine_articolo values(?,?,?)";

	// ---------------admin
	String SELECT_AMMINISTRATORE_BY_USERNAME = "Select * from amministratore where username = ?";
	String SELECT_AMMINISTRATORE = "select * from amministratore";
	String SELECT_ADMINPASS = "select password from amministratore where username=?";
	String SELECT_ARTICOLO_SEQ = "select articolo_seq.nextval from dual";
	
	String UPDATE_AMMINISTRATORE = "Update amministratore set password = ?, email = ? where username = ?";
	String UPDATE_ARTICOLO = "update articolo set marca=?, modello=?,prezzo=? where id_articolo=?";
	String UPDATE_ORDINE = "update ordine set totale=?, data=?,username=? where id_ordine=?";
	String UPDATE_UTENTE = "update utente set nome=?, cognome=?,indirizzo=?, cap=?, nascita=?, password=?, email=? where username=?";
	String UPDATE_IMMAGINE = "update immagine set url=?, descrizione=?  where id_img=?";
	
	String DELETE_AMMINISTRATORE = "Delete from amministratore where username = ?";
	String DELETE_ARTICOLO = "Delete from articolo where id_articolo = ?";
	String DELETE_ORDINE = "delete from ordine where id_ordine=?";
	String DELETE_ORDINEARTICOLO = "delete from ordine_articolo where id_ordine=?";
	

	String SELETE_ARTICOLO = "delete from articolo where id_articolo=?";

	String SELECT_REPORT = "select * from report";

	// --------------------common
	String SELECT_ARTICOLO_BY_ID = "select * from articolo where id_articolo=?";
	String SELECT_ORDINEARTICOLO_BY_ID = "select * from ordine_articolo where id_articolo=?";
	String SELECT_ARTICOLO_BY_MODELLO = "select * from articolo where modello=?";
	String SELECT_UTENTE_BY_ID = "select * from utente where username=?";
	String SELECT_ORDINE_BY_ID = "select * from ordine where id_ordine=?";
	String SELECT_IMMAGINE_BY_ID = "select * from immagine where id_img=?";
	
	//---------------------- Querystatistiche
	String TOT_ARTICOLI="select count(id_articolo) from articolo";
	String TOTALE = "select sum(totale) from ordine";
	String PRODOTTO_PIU_VENDUTO = "select articolo.id_articolo, articolo.marca, articolo.modello, articolo.prezzo, count(*) from articolo, ordine, ordine_articolo where articolo.id_articolo = ordine_articolo.id_articolo and ordine_articolo.id_ordine = ordine.id_ordine group by articolo.id_articolo, articolo.marca, articolo.modello, articolo.prezzo having count(*) = (select max(count(*)) from articolo, ordine, ordine_articolo where articolo.id_articolo = ordine_articolo.id_articolo and ordine_articolo.id_ordine = ordine.id_ordine group by articolo.modello)";
	String UTENTE_MAX_SPESA="select username, sum(totale) from ordine group by username having sum(totale) = (select max(sum(totale)) from ordine group by username)";
	
}