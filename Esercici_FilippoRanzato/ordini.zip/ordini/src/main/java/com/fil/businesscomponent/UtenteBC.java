package com.fil.businesscomponent;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import com.fil.architecture.dao.DAOException;
import com.fil.architecture.dao.UtenteDAO;
import com.fil.businesscomponent.model.Utente;
import com.fil.architecture.dbaccess.DBAccess;

public class UtenteBC {
	private Connection conn;
	
	public UtenteBC() 
			throws ClassNotFoundException, DAOException, FileNotFoundException, IOException {
		conn = DBAccess.getConnection();
	}
	
	public void create (Utente utente) throws DAOException {
		try {
			UtenteDAO.getFactory().create(conn, utente);
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
	}
	
	
	
	
	
}
