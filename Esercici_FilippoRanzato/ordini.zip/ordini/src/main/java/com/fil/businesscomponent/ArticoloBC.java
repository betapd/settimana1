package com.fil.businesscomponent;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import com.fil.architecture.dao.ArticoloDAO;
import com.fil.architecture.dao.DAOException;
import com.fil.businesscomponent.idgenerator.ArticoloIdGenerator;
import com.fil.businesscomponent.model.Articolo;
import com.fil.architecture.dbaccess.DBAccess;

public class ArticoloBC {
	private Connection conn;
	private ArticoloIdGenerator idGen;

	public ArticoloBC() throws ClassNotFoundException, DAOException, FileNotFoundException, IOException {
		conn = DBAccess.getConnection();
		idGen = ArticoloIdGenerator.getInstance();
	}

	public void createOrUpdate(Articolo articolo) throws DAOException, ClassNotFoundException, IOException {
		try {
			if (articolo.getIdArticolo() > 0)
				ArticoloDAO.getFactory().update(conn, articolo);
			else {
				articolo.setIdArticolo(idGen.getNextId());
				ArticoloDAO.getFactory().create(conn, articolo);
			}
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
	}

	public Articolo[] searchArticolo(String query) throws DAOException {
		ArrayList<Articolo> listaArticoli = new ArrayList<Articolo>(50);
		// input di igresso
		String[] criterioDiRicerca = query.toLowerCase().split(" ");

		for (Articolo a : getArticoli())
			for (String s : criterioDiRicerca)
				if (a.getMarca().toLowerCase().contains(s) || a.getModello().toLowerCase().contains(s))
					listaArticoli.add(a);

		Articolo[] articoli = new Articolo[listaArticoli.size()];
		for (int i = 0; i < listaArticoli.size(); i++) {
			articoli[i] = listaArticoli.get(i);
		}
		return articoli;
	}

	public Articolo[] getArticoli() throws DAOException {
		Articolo[] articoli = null;
		try {
			articoli = ArticoloDAO.getFactory().getAll(conn);
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
		return articoli;
	}

	public Articolo getById(Articolo articolo) throws DAOException {
		try {
			return ArticoloDAO.getFactory().getById(conn, articolo);
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
	}
	
	public Articolo getById(long id) throws DAOException {
		try {
			return ArticoloDAO.getFactory().getById(conn, id);
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
	}

	public void delete(Articolo articolo) throws DAOException {
		try {
			ArticoloDAO.getFactory().delete(conn, articolo);
		} catch (SQLException sql) {
			throw new DAOException(sql);
		}
	}

}
