insert into immagine values(1, 'img/macpro.jpg', 'MacBook Pro');
insert into immagine values(2, 'img/iphone.jpg', 'IPhone');
insert into immagine values(3, 'img/envy.png', 'HP Envy');
insert into immagine values(4, 'img/s20piccola.png', 'Samsung S20');
insert into immagine values(5, 'img/s10.png', 'Samsung S10');