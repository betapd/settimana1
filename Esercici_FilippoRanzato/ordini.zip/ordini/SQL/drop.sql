drop table utente cascade constraints;
drop table articolo cascade constraints;
drop table ordine cascade constraints;
drop table ordine_articolo cascade constraints;
drop table immagine cascade constraints;
drop table amministratore cascade constraints;
drop sequence ordine_seq;
drop sequence articolo_seq;
drop view report;