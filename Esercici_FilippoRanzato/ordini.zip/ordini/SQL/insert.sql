insert into articolo values(articolo_seq.nextval, 'Apple', 'Mac Pro', 3000.00);
insert into articolo values(articolo_seq.nextval, 'Apple', 'iPhone', 800.00);
insert into articolo values(articolo_seq.nextval, 'HP', 'Envy', 1000.00);
insert into articolo values(articolo_seq.nextval, 'Samsung', 'S20', 900.00);
insert into articolo values(articolo_seq.nextval, 'Samsung', 'S10', 750.00);

insert into amministratore values('admin', 'b0Er93$�691Ter07p$a1!fd%42Er93$�691Ter07p$a1!fd%443Er93$�691Ter07p$a1!fd%4bEr93$�691Ter07p$a1!fd%4abEr93$�691Ter07p$a1!fd%4fEr93$�691Ter07p$a1!fd%4b3Er93$�691Ter07p$a1!fd%496Er93$�691Ter07p$a1!fd%46dEr93$�691Ter07p$a1!fd%4e2Er93$�691Ter07p$a1!fd%499Er93$�691Ter07p$a1!fd%489Er93$�691Ter07p$a1!fd%43Er93$�691Ter07p$a1!fd%476Er93$�691Ter07p$a1!fd%42Er93$�691Ter07p$a1!fd%49Er93$�691Ter07p$a1!fd%4', 'admin@site.com');